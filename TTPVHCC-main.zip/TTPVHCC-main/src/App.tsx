/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Home, FileText, Calendar, MessageSquare, User } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/lib/utils';
import HomePage from './components/Home';
import ServicesPage from './components/Services';
import AppointmentPage from './components/Appointment';
import AIAssistantPage from './components/AIAssistant';
import ProfilePage from './components/Profile';

type Tab = 'home' | 'services' | 'appointment' | 'ai' | 'profile';

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('home');

  const renderContent = () => {
    switch (activeTab) {
      case 'home': return <HomePage onNavigate={setActiveTab} />;
      case 'services': return <ServicesPage />;
      case 'appointment': return <AppointmentPage />;
      case 'ai': return <AIAssistantPage />;
      case 'profile': return <ProfilePage />;
      default: return <HomePage onNavigate={setActiveTab} />;
    }
  };

  const navItems = [
    { id: 'home', icon: Home, label: 'Trang chủ' },
    { id: 'services', icon: FileText, label: 'Thủ tục' },
    { id: 'appointment', icon: Calendar, label: 'Đặt lịch' },
    { id: 'ai', icon: MessageSquare, label: 'Hỗ trợ AI' },
    { id: 'profile', icon: User, label: 'Cá nhân' },
  ];

  return (
    <div className="flex flex-col h-screen bg-background">
      {/* Header */}
      <header className="bg-primary text-primary-foreground p-4 shadow-md sticky top-0 z-50">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center">
              <span className="text-primary font-bold text-xs">TT</span>
            </div>
            <div>
              <h1 className="text-sm font-bold leading-tight">Hành chính công</h1>
              <p className="text-[10px] opacity-80 uppercase tracking-wider">Phường Tây Thạnh</p>
            </div>
          </div>
          <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
            <User className="w-4 h-4" />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto pb-20">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="h-full"
          >
            {renderContent()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 max-w-[480px] mx-auto bg-white border-t border-border flex justify-around items-center py-2 px-1 z-50">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id as Tab)}
            className={cn(
              "flex flex-col items-center gap-1 transition-colors duration-200 py-1 px-2 rounded-lg",
              activeTab === item.id ? "text-primary" : "text-muted-foreground hover:text-foreground"
            )}
          >
            <item.icon className={cn("w-5 h-5", activeTab === item.id && "fill-primary/10")} />
            <span className="text-[10px] font-medium">{item.label}</span>
            {activeTab === item.id && (
              <motion.div
                layoutId="activeTab"
                className="absolute -bottom-1 w-1 h-1 bg-primary rounded-full"
              />
            )}
          </button>
        ))}
      </nav>
    </div>
  );
}
