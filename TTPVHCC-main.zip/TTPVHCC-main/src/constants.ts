import { Procedure, NewsItem } from './types';

export const PROCEDURES: Procedure[] = [
  {
    id: '1',
    title: 'Đăng ký khai sinh',
    category: 'Hộ tịch',
    description: 'Thủ tục đăng ký khai sinh cho trẻ em mới sinh.',
    requirements: [
      'Giấy chứng sinh',
      'CCCD/Hộ chiếu của cha mẹ',
      'Giấy chứng nhận kết hôn (nếu có)'
    ],
    processingTime: 'Ngay trong ngày',
    fee: 'Miễn phí'
  },
  {
    id: '2',
    title: 'Đăng ký kết hôn',
    category: 'Hộ tịch',
    description: 'Thủ tục đăng ký kết hôn cho công dân Việt Nam.',
    requirements: [
      'Tờ khai đăng ký kết hôn',
      'CCCD/Hộ chiếu',
      'Giấy xác nhận tình trạng hôn nhân'
    ],
    processingTime: 'Ngay trong ngày',
    fee: 'Miễn phí'
  },
  {
    id: '3',
    title: 'Xác nhận tình trạng hôn nhân',
    category: 'Hộ tịch',
    description: 'Cấp giấy xác nhận tình trạng hôn nhân để làm thủ tục kết hôn hoặc mục đích khác.',
    requirements: [
      'Tờ khai cấp giấy xác nhận',
      'CCCD/Hộ chiếu',
      'Giấy tờ chứng minh tình trạng hôn nhân (nếu đã ly hôn/vợ chồng chết)'
    ],
    processingTime: '03 ngày làm việc',
    fee: '15.000 VNĐ'
  },
  {
    id: '4',
    title: 'Chứng thực bản sao từ bản chính',
    category: 'Chứng thực',
    description: 'Chứng thực bản sao các loại giấy tờ từ bản gốc.',
    requirements: [
      'Bản chính giấy tờ cần chứng thực',
      'Bản sao cần chứng thực'
    ],
    processingTime: 'Ngay trong ngày',
    fee: '2.000 VNĐ/trang'
  }
];

export const NEWS: NewsItem[] = [
  {
    id: '1',
    title: 'Thông báo về việc cấp thẻ CCCD gắn chip đợt mới',
    date: '05/04/2026',
    summary: 'Công an phường Tây Thạnh thông báo lịch cấp CCCD gắn chip cho công dân trên địa bàn.',
    imageUrl: 'https://picsum.photos/seed/police/400/200'
  },
  {
    id: '2',
    title: 'Kế hoạch tiêm chủng mở rộng tháng 4/2026',
    date: '02/04/2026',
    summary: 'Trạm y tế phường Tây Thạnh thông báo lịch tiêm chủng định kỳ cho trẻ em.',
    imageUrl: 'https://picsum.photos/seed/health/400/200'
  }
];
