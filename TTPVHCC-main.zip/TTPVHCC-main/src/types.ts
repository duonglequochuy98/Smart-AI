export interface Procedure {
  id: string;
  title: string;
  category: string;
  description: string;
  requirements: string[];
  processingTime: string;
  fee: string;
}

export interface NewsItem {
  id: string;
  title: string;
  date: string;
  summary: string;
  imageUrl: string;
}

export interface Appointment {
  id: string;
  service: string;
  date: string;
  time: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
