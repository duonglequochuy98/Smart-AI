import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export const getGeminiResponse = async (prompt: string, history: { role: 'user' | 'model', text: string }[]) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        ...history.map(h => ({ role: h.role, parts: [{ text: h.text }] })),
        { role: 'user', parts: [{ text: prompt }] }
      ],
      config: {
        systemInstruction: `Bạn là trợ lý ảo thông minh của Trung tâm Phục vụ Hành chính công phường Tây Thạnh, quận Tân Phú, TP.HCM. 
        Nhiệm vụ của bạn là hỗ trợ người dân tra cứu thông tin về các thủ tục hành chính như:
        - Hộ tịch (khai sinh, kết hôn, khai tử, xác nhận tình trạng hôn nhân...)
        - Chứng thực (bản sao, chữ ký...)
        - Đất đai, xây dựng (cấp phép xây dựng, đăng ký biến động...)
        - Các dịch vụ công trực tuyến khác.
        
        Hãy trả lời bằng tiếng Việt, lịch sự, ngắn gọn, súc tích và chính xác. 
        Nếu không biết rõ, hãy hướng dẫn người dân liên hệ trực tiếp tại trụ sở UBND phường Tây Thạnh (Địa chỉ: 100 Tây Thạnh, P. Tây Thạnh, Q. Tân Phú) hoặc gọi hotline 028 3816 1234.
        
        Luôn chào hỏi người dân một cách thân thiện.`,
        temperature: 0.7,
      }
    });

    return response.text || "Xin lỗi, tôi gặp sự cố khi kết nối. Vui lòng thử lại sau.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Xin lỗi, hiện tại tôi không thể trả lời. Vui lòng liên hệ trực tiếp UBND phường.";
  }
};
