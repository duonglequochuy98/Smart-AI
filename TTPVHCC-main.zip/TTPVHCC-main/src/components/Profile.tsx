import { User, Settings, Bell, Shield, HelpCircle, LogOut, ChevronRight, Phone, Mail, MapPin } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { Button } from '@/components/ui/button';

export default function Profile() {
  const menuItems = [
    { icon: Bell, label: 'Thông báo', color: 'text-blue-500', bg: 'bg-blue-50' },
    { icon: Shield, label: 'Bảo mật & Quyền riêng tư', color: 'text-green-500', bg: 'bg-green-50' },
    { icon: Settings, label: 'Cài đặt ứng dụng', color: 'text-gray-500', bg: 'bg-gray-50' },
    { icon: HelpCircle, label: 'Trợ giúp & Phản hồi', color: 'text-amber-500', bg: 'bg-amber-50' },
  ];

  return (
    <div className="p-4 space-y-6">
      <div className="flex flex-col items-center text-center space-y-3 pt-4">
        <div className="relative">
          <Avatar className="w-24 h-24 border-4 border-white shadow-xl">
            <AvatarImage src="https://picsum.photos/seed/user/200" />
            <AvatarFallback>DH</AvatarFallback>
          </Avatar>
          <div className="absolute bottom-0 right-0 w-8 h-8 bg-primary rounded-full border-4 border-white flex items-center justify-center text-white">
            <Settings className="w-4 h-4" />
          </div>
        </div>
        <div>
          <h2 className="text-xl font-bold">Lê Quốc Huy</h2>
          <p className="text-sm text-muted-foreground">Công dân Phường Tây Thạnh</p>
        </div>
        <div className="flex gap-2">
          <div className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-[10px] font-bold uppercase tracking-wider">
            Đã xác thực định danh
          </div>
        </div>
      </div>

      <Card className="border-none shadow-sm bg-secondary/30">
        <CardContent className="p-4 space-y-4">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center text-primary shadow-sm">
              <Phone className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <p className="text-[10px] text-muted-foreground uppercase font-bold">Số điện thoại</p>
              <p className="text-sm font-medium">090 * * * * 123</p>
            </div>
          </div>
          <Separator className="bg-white/50" />
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center text-primary shadow-sm">
              <Mail className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <p className="text-[10px] text-muted-foreground uppercase font-bold">Email</p>
              <p className="text-sm font-medium">huy.le@example.com</p>
            </div>
          </div>
          <Separator className="bg-white/50" />
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center text-primary shadow-sm">
              <MapPin className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <p className="text-[10px] text-muted-foreground uppercase font-bold">Địa chỉ thường trú</p>
              <p className="text-sm font-medium">100 Tây Thạnh, P. Tây Thạnh, Q. Tân Phú</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-2">
        <h3 className="text-sm font-bold px-2 text-muted-foreground uppercase tracking-widest">Tài khoản</h3>
        <div className="space-y-1">
          {menuItems.map((item) => (
            <button
              key={item.label}
              className="w-full flex items-center justify-between p-4 hover:bg-secondary rounded-2xl transition-colors group"
            >
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 rounded-xl ${item.bg} flex items-center justify-center ${item.color}`}>
                  <item.icon className="w-5 h-5" />
                </div>
                <span className="text-sm font-medium">{item.label}</span>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
            </button>
          ))}
        </div>
      </div>

      <Button variant="ghost" className="w-full text-destructive hover:text-destructive hover:bg-destructive/10 py-6 rounded-2xl font-bold">
        <LogOut className="mr-2 w-5 h-5" /> Đăng xuất
      </Button>

      <div className="text-center space-y-1 pt-4">
        <p className="text-[10px] text-muted-foreground">Phiên bản 1.0.0 (Build 20260408)</p>
        <p className="text-[10px] text-muted-foreground">© 2026 UBND Phường Tây Thạnh</p>
      </div>
    </div>
  );
}
