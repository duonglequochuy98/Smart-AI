import { useState } from 'react';
import { Calendar as CalendarIcon, Clock, MapPin, CheckCircle2, AlertCircle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { PROCEDURES } from '@/src/constants';
import { format, addDays, startOfToday } from 'date-fns';
import { vi } from 'date-fns/locale';

export default function Appointment() {
  const [step, setStep] = useState(1);
  const [selectedService, setSelectedService] = useState('');
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState('');

  const timeSlots = [
    '08:00', '08:30', '09:00', '09:30', '10:00', '10:30', '11:00',
    '13:30', '14:00', '14:30', '15:00', '15:30', '16:00', '16:30'
  ];

  const dates = Array.from({ length: 7 }, (_, i) => addDays(startOfToday(), i + 1))
    .filter(date => date.getDay() !== 0 && date.getDay() !== 6); // Exclude weekends

  const handleConfirm = () => {
    setStep(4);
  };

  if (step === 4) {
    return (
      <div className="p-6 flex flex-col items-center justify-center h-full text-center space-y-6">
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center text-green-600">
          <CheckCircle2 className="w-12 h-12" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-bold">Đặt lịch thành công!</h2>
          <p className="text-sm text-muted-foreground">
            Mã số hẹn của bạn là <span className="font-bold text-primary">TT-2026-0408</span>. 
            Vui lòng đến đúng giờ hẹn.
          </p>
        </div>
        <Card className="w-full bg-secondary/30 border-dashed">
          <CardContent className="p-4 text-left space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Dịch vụ:</span>
              <span className="font-bold">{selectedService}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Thời gian:</span>
              <span className="font-bold">{selectedTime}, {selectedDate && format(selectedDate, 'dd/MM/yyyy')}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Địa điểm:</span>
              <span className="font-bold">UBND Phường Tây Thạnh</span>
            </div>
          </CardContent>
        </Card>
        <Button className="w-full" onClick={() => setStep(1)}>Quay lại trang chủ</Button>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-6">
      <div className="space-y-2">
        <h2 className="text-2xl font-bold">Đặt lịch hẹn</h2>
        <p className="text-sm text-muted-foreground">Chủ động thời gian, không cần chờ đợi tại trung tâm.</p>
      </div>

      {/* Progress */}
      <div className="flex items-center justify-between px-4">
        {[1, 2, 3].map((s) => (
          <div key={s} className="flex items-center">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-colors ${
              step >= s ? 'bg-primary text-white' : 'bg-secondary text-muted-foreground'
            }`}>
              {s}
            </div>
            {s < 3 && (
              <div className={`w-16 h-0.5 mx-2 ${step > s ? 'bg-primary' : 'bg-secondary'}`} />
            )}
          </div>
        ))}
      </div>

      {step === 1 && (
        <div className="space-y-4">
          <h3 className="font-bold">Chọn dịch vụ cần thực hiện</h3>
          <div className="space-y-3">
            {PROCEDURES.map(p => (
              <Card 
                key={p.id} 
                className={`cursor-pointer transition-all ${selectedService === p.title ? 'border-primary bg-primary/5 ring-1 ring-primary' : ''}`}
                onClick={() => setSelectedService(p.title)}
              >
                <CardContent className="p-4 flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${selectedService === p.title ? 'bg-primary text-white' : 'bg-secondary text-primary'}`}>
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-bold">{p.title}</p>
                    <p className="text-[10px] text-muted-foreground">{p.category}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          <Button 
            className="w-full py-6 rounded-2xl font-bold" 
            disabled={!selectedService}
            onClick={() => setStep(2)}
          >
            Tiếp theo
          </Button>
        </div>
      )}

      {step === 2 && (
        <div className="space-y-6">
          <div className="space-y-4">
            <h3 className="font-bold flex items-center gap-2">
              <CalendarIcon className="w-4 h-4 text-primary" /> Chọn ngày hẹn
            </h3>
            <div className="flex gap-3 overflow-x-auto pb-2">
              {dates.map((date) => (
                <button
                  key={date.toISOString()}
                  onClick={() => setSelectedDate(date)}
                  className={`flex flex-col items-center min-w-[70px] p-3 rounded-2xl border transition-all ${
                    selectedDate?.toDateString() === date.toDateString() 
                      ? 'border-primary bg-primary text-white shadow-lg shadow-primary/20' 
                      : 'bg-white border-border hover:border-primary/50'
                  }`}
                >
                  <span className="text-[10px] uppercase font-bold opacity-80">
                    {format(date, 'EEE', { locale: vi })}
                  </span>
                  <span className="text-lg font-bold">{format(date, 'dd')}</span>
                  <span className="text-[10px] opacity-80">{format(date, 'MMM', { locale: vi })}</span>
                </button>
              ))}
            </div>
          </div>

          {selectedDate && (
            <div className="space-y-4">
              <h3 className="font-bold flex items-center gap-2">
                <Clock className="w-4 h-4 text-primary" /> Chọn giờ hẹn
              </h3>
              <div className="grid grid-cols-4 gap-2">
                {timeSlots.map((time) => (
                  <button
                    key={time}
                    onClick={() => setSelectedTime(time)}
                    className={`py-2 px-1 rounded-lg border text-xs font-medium transition-all ${
                      selectedTime === time 
                        ? 'border-primary bg-primary text-white' 
                        : 'bg-white border-border hover:border-primary/50'
                    }`}
                  >
                    {time}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="flex gap-3 pt-4">
            <Button variant="outline" className="flex-1" onClick={() => setStep(1)}>Quay lại</Button>
            <Button 
              className="flex-[2]" 
              disabled={!selectedDate || !selectedTime}
              onClick={() => setStep(3)}
            >
              Tiếp theo
            </Button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="space-y-6">
          <h3 className="font-bold text-lg">Xác nhận thông tin</h3>
          <Card className="overflow-hidden border-primary/20">
            <div className="bg-primary/5 p-4 border-b border-primary/10">
              <p className="text-[10px] text-primary uppercase font-bold tracking-widest">Thông tin lịch hẹn</p>
            </div>
            <CardContent className="p-4 space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-[10px] text-muted-foreground uppercase font-bold">Dịch vụ</p>
                  <p className="text-sm font-bold">{selectedService}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0">
                  <CalendarIcon className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-[10px] text-muted-foreground uppercase font-bold">Thời gian</p>
                  <p className="text-sm font-bold">
                    {selectedTime}, {selectedDate && format(selectedDate, 'EEEE, dd/MM/yyyy', { locale: vi })}
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-[10px] text-muted-foreground uppercase font-bold">Địa điểm</p>
                  <p className="text-sm font-bold">UBND Phường Tây Thạnh</p>
                  <p className="text-xs text-muted-foreground">100 Tây Thạnh, P. Tây Thạnh, Q. Tân Phú</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="bg-amber-50 border border-amber-100 p-4 rounded-xl flex gap-3">
            <AlertCircle className="w-5 h-5 text-amber-600 shrink-0" />
            <p className="text-xs text-amber-800 leading-relaxed">
              Vui lòng mang theo đầy đủ hồ sơ bản chính và có mặt trước giờ hẹn 10 phút để làm thủ tục check-in.
            </p>
          </div>

          <div className="flex gap-3 pt-4">
            <Button variant="outline" className="flex-1" onClick={() => setStep(2)}>Quay lại</Button>
            <Button className="flex-[2]" onClick={handleConfirm}>Xác nhận đặt lịch</Button>
          </div>
        </div>
      )}
    </div>
  );
}
