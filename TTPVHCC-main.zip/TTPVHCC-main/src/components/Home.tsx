import { Search, Bell, ArrowRight, FileText, Calendar, MessageSquare, Info } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { NEWS } from '@/src/constants';

interface HomeProps {
  onNavigate: (tab: 'home' | 'services' | 'appointment' | 'ai' | 'profile') => void;
}

export default function Home({ onNavigate }: HomeProps) {
  return (
    <div className="p-4 space-y-6">
      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          type="text"
          placeholder="Tìm kiếm thủ tục hành chính..."
          className="w-full pl-10 pr-4 py-2 bg-secondary rounded-full text-sm border-none focus:ring-2 focus:ring-primary outline-none"
        />
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-4 gap-2">
        {[
          { icon: FileText, label: 'Thủ tục', tab: 'services' },
          { icon: Calendar, label: 'Đặt lịch', tab: 'appointment' },
          { icon: MessageSquare, label: 'Hỗ trợ AI', tab: 'ai' },
          { icon: Info, label: 'Thông tin', tab: 'profile' },
        ].map((item) => (
          <button
            key={item.label}
            onClick={() => onNavigate(item.tab as any)}
            className="flex flex-col items-center gap-2 p-2 hover:bg-secondary rounded-xl transition-colors"
          >
            <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary">
              <item.icon className="w-6 h-6" />
            </div>
            <span className="text-[10px] font-medium text-center">{item.label}</span>
          </button>
        ))}
      </div>

      {/* Featured Service Card */}
      <Card className="bg-gradient-to-br from-primary to-blue-700 text-white border-none overflow-hidden relative">
        <CardContent className="p-6">
          <div className="space-y-2 relative z-10">
            <Badge className="bg-white/20 text-white border-none">Mới</Badge>
            <h3 className="text-xl font-bold">Dịch vụ công trực tuyến</h3>
            <p className="text-sm opacity-90">Nộp hồ sơ trực tuyến, tiết kiệm thời gian và công sức.</p>
            <Button variant="secondary" size="sm" className="mt-2" onClick={() => onNavigate('services')}>
              Khám phá ngay <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </div>
          <div className="absolute right-[-20px] bottom-[-20px] opacity-10">
            <FileText className="w-32 h-32" />
          </div>
        </CardContent>
      </Card>

      {/* News Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="font-bold text-lg">Tin tức & Thông báo</h2>
          <button className="text-primary text-xs font-medium">Xem tất cả</button>
        </div>
        <div className="space-y-4">
          {NEWS.map((item) => (
            <div key={item.id} className="flex gap-4 items-start group">
              <img
                src={item.imageUrl}
                alt={item.title}
                className="w-24 h-24 rounded-xl object-cover shadow-sm"
                referrerPolicy="no-referrer"
              />
              <div className="flex-1 space-y-1">
                <p className="text-[10px] text-muted-foreground font-medium">{item.date}</p>
                <h4 className="text-sm font-bold leading-snug group-hover:text-primary transition-colors">
                  {item.title}
                </h4>
                <p className="text-xs text-muted-foreground line-clamp-2">
                  {item.summary}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-secondary/50 p-4 rounded-2xl border border-border/50">
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-bold">Hồ sơ đã giải quyết</p>
          <p className="text-2xl font-bold text-primary">12,450+</p>
        </div>
        <div className="bg-secondary/50 p-4 rounded-2xl border border-border/50">
          <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-bold">Tỷ lệ hài lòng</p>
          <p className="text-2xl font-bold text-green-600">98.5%</p>
        </div>
      </div>
    </div>
  );
}
