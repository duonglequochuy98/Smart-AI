import { useState } from 'react';
import { Search, ChevronRight, Clock, Banknote, FileCheck } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { PROCEDURES } from '@/src/constants';
import { Procedure } from '@/src/types';

export default function Services() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProcedure, setSelectedProcedure] = useState<Procedure | null>(null);

  const filteredProcedures = PROCEDURES.filter(p => 
    p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const categories = Array.from(new Set(PROCEDURES.map(p => p.category)));

  return (
    <div className="p-4 space-y-6">
      <div className="space-y-2">
        <h2 className="text-2xl font-bold">Thủ tục hành chính</h2>
        <p className="text-sm text-muted-foreground">Tra cứu thông tin và hướng dẫn thực hiện các thủ tục tại phường.</p>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Tìm tên thủ tục..."
          className="pl-10 rounded-full"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="w-full justify-start overflow-x-auto bg-transparent h-auto p-0 gap-2 mb-4">
          <TabsTrigger value="all" className="rounded-full border data-[state=active]:bg-primary data-[state=active]:text-white">
            Tất cả
          </TabsTrigger>
          {categories.map(cat => (
            <TabsTrigger key={cat} value={cat} className="rounded-full border data-[state=active]:bg-primary data-[state=active]:text-white">
              {cat}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="all" className="space-y-3">
          {filteredProcedures.map(p => (
            <div key={p.id}>
              <ProcedureCard procedure={p} onClick={() => setSelectedProcedure(p)} />
            </div>
          ))}
        </TabsContent>

        {categories.map(cat => (
          <TabsContent key={cat} value={cat} className="space-y-3">
            {filteredProcedures.filter(p => p.category === cat).map(p => (
              <div key={p.id}>
                <ProcedureCard procedure={p} onClick={() => setSelectedProcedure(p)} />
              </div>
            ))}
          </TabsContent>
        ))}
      </Tabs>

      {/* Procedure Detail Sheet */}
      <Sheet open={!!selectedProcedure} onOpenChange={(open) => !open && setSelectedProcedure(null)}>
        <SheetContent side="bottom" className="h-[85vh] rounded-t-3xl p-0 overflow-hidden">
          {selectedProcedure && (
            <div className="flex flex-col h-full">
              <div className="p-6 space-y-4 overflow-y-auto flex-1">
                <SheetHeader className="space-y-2">
                  <Badge className="w-fit">{selectedProcedure.category}</Badge>
                  <SheetTitle className="text-2xl font-bold text-left">{selectedProcedure.title}</SheetTitle>
                </SheetHeader>

                <div className="space-y-6 pt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-secondary/50 p-3 rounded-xl flex items-center gap-3">
                      <Clock className="w-5 h-5 text-primary" />
                      <div>
                        <p className="text-[10px] text-muted-foreground uppercase font-bold">Thời gian</p>
                        <p className="text-xs font-medium">{selectedProcedure.processingTime}</p>
                      </div>
                    </div>
                    <div className="bg-secondary/50 p-3 rounded-xl flex items-center gap-3">
                      <Banknote className="w-5 h-5 text-primary" />
                      <div>
                        <p className="text-[10px] text-muted-foreground uppercase font-bold">Lệ phí</p>
                        <p className="text-xs font-medium">{selectedProcedure.fee}</p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-bold flex items-center gap-2">
                      <Info className="w-4 h-4 text-primary" /> Mô tả
                    </h4>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {selectedProcedure.description}
                    </p>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-bold flex items-center gap-2">
                      <FileCheck className="w-4 h-4 text-primary" /> Thành phần hồ sơ
                    </h4>
                    <ul className="space-y-2">
                      {selectedProcedure.requirements.map((req, i) => (
                        <li key={i} className="flex items-start gap-3 text-sm text-muted-foreground">
                          <div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
                          {req}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
              
              <div className="p-6 border-t bg-white sticky bottom-0">
                <button className="w-full bg-primary text-white py-4 rounded-2xl font-bold shadow-lg shadow-primary/20 active:scale-95 transition-transform">
                  Nộp hồ sơ trực tuyến
                </button>
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}

function ProcedureCard({ procedure, onClick }: { procedure: Procedure; onClick: () => void }) {
  return (
    <Card className="hover:border-primary/50 transition-colors cursor-pointer group" onClick={onClick}>
      <CardContent className="p-4 flex items-center justify-between">
        <div className="space-y-1">
          <Badge variant="secondary" className="text-[10px] font-bold uppercase tracking-wider">
            {procedure.category}
          </Badge>
          <h4 className="font-bold text-sm group-hover:text-primary transition-colors">
            {procedure.title}
          </h4>
          <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3" /> {procedure.processingTime}
            </span>
            <span className="flex items-center gap-1">
              <Banknote className="w-3 h-3" /> {procedure.fee}
            </span>
          </div>
        </div>
        <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors" />
      </CardContent>
    </Card>
  );
}

function Info({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <circle cx="12" cy="12" r="10" />
      <path d="M12 16v-4" />
      <path d="M12 8h.01" />
    </svg>
  );
}
