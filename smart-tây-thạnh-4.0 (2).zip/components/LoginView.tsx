
import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  User, 
  CreditCard, 
  ShieldCheck, 
  CheckCircle2, 
  Sparkles, 
  Mail, 
  Smartphone,
  Loader2,
  Fingerprint,
  QrCode,
  Shield
} from 'lucide-react';

interface LoginViewProps {
  onBack: () => void;
  onLoginSuccess: (name: string, cccd: string) => void;
}

export const LoginView: React.FC<LoginViewProps> = ({ onBack, onLoginSuccess }) => {
  const [name, setName] = useState('');
  const [cccd, setCccd] = useState('');
  const [email, setEmail] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);
  const [isVNeIDLoading, setIsVNeIDLoading] = useState(false);
  const [vneidStep, setVneidStep] = useState<'idle' | 'authorizing' | 'success'>('idle');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() && cccd.length === 12) {
      saveAndFinish(name.trim(), cccd, email.trim());
    }
  };

  const saveAndFinish = (nameStr: string, cccdStr: string, emailStr: string) => {
    localStorage.setItem('smart_taythanh_user_name', nameStr);
    localStorage.setItem('smart_taythanh_user_cccd', cccdStr);
    localStorage.setItem('smart_taythanh_user_email', emailStr);
    
    setIsSuccess(true);
    setTimeout(() => {
      onLoginSuccess(nameStr, cccdStr);
    }, 1500);
  };

  const handleVNeIDLogin = () => {
    setIsVNeIDLoading(true);
    setVneidStep('authorizing');
    
    // Giả lập quy trình kết nối với ứng dụng VNeID
    setTimeout(() => {
      const mockData = {
        name: "NGUYỄN VĂN AN",
        cccd: "079090123456",
        email: "an.nguyen@vneid.gov.vn"
      };
      
      setName(mockData.name);
      setCccd(mockData.cccd);
      setEmail(mockData.email);
      setVneidStep('success');
      
      setTimeout(() => {
        saveAndFinish(mockData.name, mockData.cccd, mockData.email);
      }, 1000);
    }, 2500);
  };

  if (isSuccess) {
    return (
      <div className="flex flex-col h-full bg-white items-center justify-center p-8 text-center animate-in zoom-in duration-500">
        <div className="w-24 h-24 bg-emerald-50 rounded-[32px] flex items-center justify-center text-emerald-500 mb-6 shadow-inner border-2 border-emerald-100">
          <CheckCircle2 size={48} />
        </div>
        <h2 className="text-2xl font-black text-slate-900 mb-2">Định danh thành công!</h2>
        <p className="text-sm text-slate-500 font-medium">Chào mừng ông/bà <span className="text-red-600 font-bold">{name}</span></p>
        <div className="mt-4 px-4 py-2 bg-slate-50 rounded-full border border-slate-100 flex items-center gap-2">
          <ShieldCheck size={14} className="text-emerald-500" />
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Dữ liệu đã được xác thực qua VNeID</span>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-white animate-in fade-in slide-in-from-bottom-4 duration-500 overflow-y-auto no-scrollbar relative">
      <div className="p-4 flex items-center justify-between sticky top-0 bg-white/80 backdrop-blur-md z-10">
        <button onClick={onBack} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-slate-100 transition-colors">
          <ArrowLeft size={22} className="text-slate-700" />
        </button>
        <div className="px-3 py-1 bg-red-50 rounded-full border border-red-100">
           <span className="text-[9px] font-black text-red-600 uppercase tracking-widest">Hệ thống định danh 4.0</span>
        </div>
      </div>

      <div className="px-8 pt-6 pb-6 space-y-3">
        <div className="flex items-center gap-4 mb-2">
          <div className="w-14 h-14 bg-red-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-red-600/20">
            <ShieldCheck size={28} />
          </div>
          <div className="w-14 h-14 bg-amber-500 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-amber-500/20">
            <Fingerprint size={28} />
          </div>
        </div>
        <h2 className="text-3xl font-black text-slate-900 tracking-tight">Định danh Công dân</h2>
        <p className="text-sm text-slate-500 font-semibold leading-relaxed">
          Sử dụng ứng dụng <span className="text-red-600 font-black">VNeID</span> để đăng nhập nhanh hoặc điền thông tin thủ công bên dưới.
        </p>
      </div>

      <div className="px-8 space-y-6 flex-1 pb-10">
        {/* VNeID Login Section */}
        <div className="space-y-4">
          <button 
            type="button"
            onClick={handleVNeIDLogin}
            disabled={isVNeIDLoading}
            className="w-full group relative h-20 bg-gradient-to-r from-red-600 to-red-700 rounded-[24px] p-1 shadow-xl shadow-red-600/20 active:scale-[0.98] transition-all overflow-hidden"
          >
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
            <div className="relative h-full w-full bg-white/5 rounded-[20px] flex items-center justify-between px-6 border border-white/10">
               <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-md">
                     <img 
                       src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0D0k4z4x0vQ8vX_y8-VvV4S8X_4_8YvV4Sg&s" 
                       alt="VNeID" 
                       className="w-8 h-8 object-contain"
                     />
                  </div>
                  <div className="text-left">
                     <p className="text-[10px] font-black text-white/60 uppercase tracking-widest">Đăng nhập nhanh qua</p>
                     <p className="text-lg font-black text-white leading-none">Ứng dụng VNeID</p>
                  </div>
               </div>
               <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white">
                  {isVNeIDLoading ? <Loader2 size={18} className="animate-spin" /> : <QrCode size={18} />}
               </div>
            </div>
          </button>

          <div className="flex items-center gap-4 py-2">
            <div className="h-[1px] flex-1 bg-slate-100"></div>
            <span className="text-[10px] font-black text-slate-300 uppercase tracking-[0.2em]">Hoặc nhập thủ công</span>
            <div className="h-[1px] flex-1 bg-slate-100"></div>
          </div>
        </div>

        {/* Manual Form */}
        <form onSubmit={handleLogin} className="space-y-5">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Họ và tên (có dấu)</label>
            <div className="relative group">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-red-500 transition-colors" size={18} />
              <input 
                required
                type="text" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="NGUYỄN VĂN A"
                className="w-full h-14 bg-slate-50 border border-slate-200 rounded-2xl pl-12 pr-4 text-sm font-extrabold focus:bg-white focus:border-red-500 focus:ring-4 focus:ring-red-500/5 transition-all outline-none uppercase"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Số định danh cá nhân / CCCD</label>
            <div className="relative group">
              <CreditCard className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-red-500 transition-colors" size={18} />
              <input 
                required
                type="text" 
                maxLength={12}
                value={cccd}
                onChange={(e) => setCccd(e.target.value.replace(/\D/g, ''))}
                placeholder="079xxxxxxxx"
                className="w-full h-14 bg-slate-50 border border-slate-200 rounded-2xl pl-12 pr-4 text-sm font-extrabold focus:bg-white focus:border-red-500 focus:ring-4 focus:ring-red-500/5 transition-all outline-none"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Địa chỉ Email liên hệ</label>
            <div className="relative group">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-red-500 transition-colors" size={18} />
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="example@gmail.com"
                className="w-full h-14 bg-slate-50 border border-slate-200 rounded-2xl pl-12 pr-4 text-sm font-extrabold focus:bg-white focus:border-red-500 focus:ring-4 focus:ring-red-500/5 transition-all outline-none"
              />
            </div>
          </div>

          <button 
            type="submit"
            disabled={!name.trim() || cccd.length !== 12 || isVNeIDLoading}
            className="w-full h-16 bg-slate-900 text-white rounded-2xl font-black text-base shadow-xl shadow-slate-900/20 active:scale-[0.98] transition-all disabled:opacity-30 flex items-center justify-center gap-3 uppercase tracking-widest mt-4"
          >
            Đăng nhập hệ thống
            <ArrowLeft className="rotate-180" size={18} />
          </button>
        </form>
      </div>

      <div className="p-8 flex flex-col items-center bg-slate-50 border-t border-slate-100">
        <div className="flex items-center gap-2 mb-2 text-slate-400">
          <Shield size={14} />
          <span className="text-[10px] font-black uppercase tracking-widest">Chính sách bảo mật</span>
        </div>
        <p className="text-[10px] text-slate-400 font-bold leading-relaxed text-center">
          Thông tin được bảo mật và mã hóa theo quy định của Bộ Công an và UBND Phường Tây Thạnh. Hệ thống Smart Tây Thạnh 4.0 cam kết không chia sẻ dữ liệu cho bên thứ ba.
        </p>
      </div>

      {/* VNeID Authorization Modal Animation */}
      {vneidStep !== 'idle' && (
        <div className="absolute inset-0 z-[100] flex items-center justify-center p-6 bg-slate-900/40 backdrop-blur-md animate-in fade-in duration-300">
           <div className="w-full max-w-[320px] bg-white rounded-[40px] p-8 flex flex-col items-center text-center shadow-2xl border border-white animate-in zoom-in duration-500">
              {vneidStep === 'authorizing' ? (
                <>
                  <div className="relative mb-8">
                     <div className="w-24 h-24 bg-red-50 rounded-full flex items-center justify-center animate-pulse">
                        <img 
                          src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0D0k4z4x0vQ8vX_y8-VvV4S8X_4_8YvV4Sg&s" 
                          alt="VNeID" 
                          className="w-16 h-16 object-contain"
                        />
                     </div>
                     <div className="absolute inset-0 border-4 border-red-500 border-t-transparent rounded-full animate-spin"></div>
                  </div>
                  <h3 className="text-xl font-black text-slate-900 mb-2">Đang xác thực...</h3>
                  <p className="text-xs text-slate-500 font-bold mb-6 px-4">Vui lòng chờ trong khi hệ thống kết nối an toàn với cơ sở dữ liệu định danh.</p>
                  <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                     <div className="h-full bg-red-600 animate-[loading-shimmer_1.5s_infinite_linear] w-1/2 rounded-full"></div>
                  </div>
                </>
              ) : (
                <>
                  <div className="w-24 h-24 bg-emerald-50 rounded-full flex items-center justify-center text-emerald-500 mb-8 border-4 border-emerald-100">
                     <Sparkles size={48} className="animate-bounce" />
                  </div>
                  <h3 className="text-xl font-black text-slate-900 mb-2">Xác thực xong!</h3>
                  <p className="text-xs text-slate-500 font-bold mb-6">Đã thu thập dữ liệu định danh từ VNeID.</p>
                  <div className="w-full space-y-2 text-left bg-slate-50 p-4 rounded-2xl border border-slate-100">
                     <div className="flex items-center gap-2">
                        <div className="w-1 h-1 bg-emerald-500 rounded-full"></div>
                        <span className="text-[10px] font-black text-slate-400 uppercase">Họ tên: NGUYỄN VĂN AN</span>
                     </div>
                     <div className="flex items-center gap-2">
                        <div className="w-1 h-1 bg-emerald-500 rounded-full"></div>
                        <span className="text-[10px] font-black text-slate-400 uppercase">Số CCCD: 079090123456</span>
                     </div>
                  </div>
                </>
              )}
           </div>
        </div>
      )}

      <style>{`
        @keyframes loading-shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(200%); }
        }
      `}</style>
    </div>
  );
};
