
import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Search, 
  ChevronRight, 
  FileText, 
  BookOpen, 
  Info, 
  ShieldCheck, 
  Clock, 
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

interface HandbookViewProps {
  onBack: () => void;
}

const HANDBOOK_DATA = [
  {
    id: 1,
    title: "Đăng ký khai sinh",
    category: "Hộ tịch",
    time: "Trong ngày",
    fee: "Miễn phí",
    docs: ["Tờ khai đăng ký khai sinh", "Giấy chứng sinh", "CCCD/Hộ chiếu người đi đăng ký"],
    steps: [
      "Nộp hồ sơ trực tuyến hoặc trực tiếp tại UBND Phường.",
      "Cán bộ tiếp nhận kiểm tra tính hợp lệ của hồ sơ.",
      "Thực hiện đăng ký và trả kết quả ngay trong ngày làm việc."
    ]
  },
  {
    id: 2,
    title: "Chứng thực bản sao",
    category: "Chứng thực",
    time: "Trong ngày",
    fee: "2.000đ/trang",
    docs: ["Bản chính giấy tờ cần chứng thực", "Bản photo tương ứng"],
    steps: [
      "Xuất trình bản chính và nộp bản photo.",
      "Cán bộ đối chiếu nội dung bản photo với bản chính.",
      "Ký chứng thực và đóng dấu trả kết quả."
    ]
  },
  {
    id: 3,
    title: "Xác nhận tình trạng hôn nhân",
    category: "Hộ tịch",
    time: "03 ngày làm việc",
    fee: "15.000đ",
    docs: ["Tờ khai xác nhận tình trạng hôn nhân", "Trích lục bản án ly hôn (nếu có)", "CCCD"],
    steps: [
      "Nộp hồ sơ tại bộ phận Một cửa.",
      "Cán bộ kiểm tra, xác minh thông tin cư trú.",
      "Ký và cấp Giấy xác nhận tình trạng hôn nhân."
    ]
  }
];

export const HandbookView: React.FC<HandbookViewProps> = ({ onBack }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedItem, setSelectedItem] = useState<typeof HANDBOOK_DATA[0] | null>(null);

  const filteredData = HANDBOOK_DATA.filter(item => 
    item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex flex-col h-full bg-[#F8FAFC] overflow-y-auto animate-in fade-in duration-500 pb-24 no-scrollbar">
      <div className="p-4 flex items-center gap-4 sticky top-0 bg-white/80 backdrop-blur-md z-20 border-b border-slate-100">
        <button onClick={onBack} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-slate-100 transition-colors">
          <ArrowLeft size={20} className="text-slate-800" />
        </button>
        <h2 className="text-base font-bold text-slate-900">Cẩm nang hành chính</h2>
      </div>

      <div className="px-5 pt-6 space-y-6">
        <div className="relative">
          <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none text-slate-400">
            <Search size={18} />
          </div>
          <input 
            type="text" 
            placeholder="Tìm kiếm thủ tục..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-14 pl-12 pr-4 bg-white border border-slate-100 rounded-[20px] text-sm font-medium focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 transition-all shadow-sm"
          />
        </div>

        {!selectedItem ? (
          <div className="space-y-4">
            <div className="flex items-center justify-between px-1">
              <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-widest">Thủ tục phổ biến</h4>
              <BookOpen size={14} className="text-red-500" />
            </div>
            <div className="grid grid-cols-1 gap-3">
              {filteredData.map((item) => (
                <button 
                  key={item.id}
                  onClick={() => setSelectedItem(item)}
                  className="bg-white p-5 rounded-[24px] border border-slate-100 shadow-sm flex items-center justify-between hover:border-red-100 transition-all active:scale-[0.98]"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-red-50 flex items-center justify-center text-red-600">
                      <FileText size={22} />
                    </div>
                    <div className="text-left">
                      <h5 className="text-[15px] font-bold text-slate-800 leading-tight">{item.title}</h5>
                      <div className="flex items-center gap-2 mt-1.5">
                        <span className="px-2 py-0.5 bg-slate-100 text-slate-500 text-[10px] font-bold rounded-md uppercase">{item.category}</span>
                        <div className="flex items-center gap-1 text-[10px] font-bold text-emerald-600">
                          <Clock size={10} /> {item.time}
                        </div>
                      </div>
                    </div>
                  </div>
                  <ChevronRight size={18} className="text-slate-300" />
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="animate-in slide-in-from-right duration-300 space-y-6">
            <button 
              onClick={() => setSelectedItem(null)}
              className="flex items-center gap-2 text-[12px] font-bold text-red-600 mb-2"
            >
              <ArrowLeft size={14} /> Quay lại danh sách
            </button>

            <div className="bg-white rounded-[28px] p-6 border border-slate-100 shadow-sm space-y-6">
              <div>
                <h3 className="text-lg font-black text-slate-900 mb-2">{selectedItem.title}</h3>
                <div className="flex flex-wrap gap-2">
                  <span className="px-3 py-1 bg-red-50 text-red-600 text-[10px] font-black rounded-full uppercase border border-red-100">{selectedItem.category}</span>
                  <span className="px-3 py-1 bg-emerald-50 text-emerald-600 text-[10px] font-black rounded-full uppercase border border-emerald-100">{selectedItem.fee}</span>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
                  <Info size={18} className="text-red-500" /> Hồ sơ cần chuẩn bị
                </div>
                <ul className="space-y-2.5">
                  {selectedItem.docs.map((doc, idx) => (
                    <li key={idx} className="flex items-start gap-3 text-slate-600 text-[13px] leading-relaxed">
                      <div className="w-5 h-5 rounded-full bg-slate-50 flex items-center justify-center shrink-0 mt-0.5">
                        <div className="w-1.5 h-1.5 rounded-full bg-slate-300"></div>
                      </div>
                      {doc}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
                  <ShieldCheck size={18} className="text-red-500" /> Quy trình thực hiện
                </div>
                <div className="space-y-4">
                  {selectedItem.steps.map((step, idx) => (
                    <div key={idx} className="flex gap-4">
                      <div className="flex flex-col items-center shrink-0">
                        <div className="w-7 h-7 rounded-full bg-red-600 text-white flex items-center justify-center text-[11px] font-black shadow-lg shadow-red-600/20 z-10">
                          {idx + 1}
                        </div>
                        {idx < selectedItem.steps.length - 1 && (
                          <div className="w-0.5 h-full bg-slate-100 -mt-1"></div>
                        )}
                      </div>
                      <p className="text-slate-600 text-[13px] leading-relaxed pt-0.5">{step}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-4 bg-amber-50 border border-amber-100 rounded-2xl flex gap-3">
                <AlertCircle size={20} className="text-amber-600 shrink-0" />
                <p className="text-[11px] text-amber-800 font-medium leading-relaxed">
                  Lưu ý: Thông tin trên chỉ mang tính chất tham khảo. Vui lòng liên hệ Trợ lý AI hoặc Cán bộ tại UBND để được hướng dẫn chi tiết nhất.
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="p-6 bg-slate-900 rounded-[28px] text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <CheckCircle2 size={64} />
          </div>
          <div className="relative z-10">
            <h4 className="text-sm font-black mb-1">Nộp hồ sơ trực tuyến?</h4>
            <p className="text-[11px] text-white/60 mb-4">Tiết kiệm thời gian, không cần chờ đợi.</p>
            <button className="px-4 py-2 bg-white text-slate-900 rounded-xl text-[11px] font-black uppercase tracking-wider active:scale-95 transition-all">
              Thử ngay
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
