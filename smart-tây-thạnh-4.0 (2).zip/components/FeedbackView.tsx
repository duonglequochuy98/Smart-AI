
import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Camera, 
  MapPin, 
  Send, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  MessageSquare,
  Image as ImageIcon,
  Trash2,
  Lightbulb,
  Construction,
  Droplets
} from 'lucide-react';

interface FeedbackViewProps {
  onBack: () => void;
}

const CATEGORIES = [
  { id: 'trash', label: 'Rác thải', icon: <Trash2 size={18} />, color: 'bg-orange-50 text-orange-600' },
  { id: 'light', label: 'Đèn đường', icon: <Lightbulb size={18} />, color: 'bg-yellow-50 text-yellow-600' },
  { id: 'road', label: 'Đường sá', icon: <Construction size={18} />, color: 'bg-blue-50 text-blue-600' },
  { id: 'water', label: 'Cấp thoát nước', icon: <Droplets size={18} />, color: 'bg-cyan-50 text-cyan-600' },
  { id: 'other', label: 'Khác', icon: <AlertTriangle size={18} />, color: 'bg-slate-50 text-slate-600' },
];

export const FeedbackView: React.FC<FeedbackViewProps> = ({ onBack }) => {
  const [step, setStep] = useState<'form' | 'success'>('form');
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState("");
  const [image, setImage] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!category || !description) return;
    setStep('success');
  };

  const handleImageUpload = () => {
    // Mock image upload
    setImage("https://picsum.photos/seed/report/400/300");
  };

  if (step === 'success') {
    return (
      <div className="flex flex-col h-full bg-white items-center justify-center p-8 text-center animate-in fade-in zoom-in duration-500">
        <div className="w-24 h-24 bg-emerald-50 rounded-[32px] flex items-center justify-center text-emerald-600 mb-8 shadow-inner">
          <CheckCircle2 size={48} />
        </div>
        <h3 className="text-2xl font-black text-slate-900 mb-3 tracking-tight">Gửi phản ánh thành công!</h3>
        <p className="text-slate-500 text-[14px] leading-relaxed mb-10 px-4">
          Cảm ơn ông/bà đã đóng góp ý kiến xây dựng Phường Tây Thạnh văn minh, hiện đại. Chúng tôi sẽ xử lý và phản hồi sớm nhất.
        </p>
        <div className="w-full space-y-3">
          <button 
            onClick={onBack}
            className="w-full h-14 bg-slate-900 text-white rounded-[20px] font-extrabold text-sm shadow-xl active:scale-95 transition-all"
          >
            Quay lại trang chủ
          </button>
          <button 
            onClick={() => setStep('form')}
            className="w-full h-14 bg-slate-50 text-slate-600 rounded-[20px] font-extrabold text-sm active:scale-95 transition-all"
          >
            Gửi phản ánh khác
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-[#F8FAFC] overflow-y-auto animate-in fade-in duration-500 pb-24 no-scrollbar">
      <div className="p-4 flex items-center gap-4 sticky top-0 bg-white/80 backdrop-blur-md z-20 border-b border-slate-100">
        <button onClick={onBack} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-slate-100 transition-colors">
          <ArrowLeft size={20} className="text-slate-800" />
        </button>
        <h2 className="text-base font-bold text-slate-900">Phản ánh kiến nghị</h2>
      </div>

      <form onSubmit={handleSubmit} className="px-5 pt-6 space-y-8">
        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-widest">Chọn lĩnh vực</h4>
            <AlertTriangle size={14} className="text-orange-500" />
          </div>
          <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setCategory(cat.id)}
                className={`flex flex-col items-center gap-2 p-4 rounded-[24px] min-w-[100px] border-2 transition-all active:scale-95 ${
                  category === cat.id 
                    ? 'bg-white border-red-500 shadow-lg shadow-red-500/10' 
                    : 'bg-white border-transparent shadow-sm'
                }`}
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${cat.color}`}>
                  {cat.icon}
                </div>
                <span className={`text-[11px] font-black uppercase tracking-tighter ${category === cat.id ? 'text-red-600' : 'text-slate-500'}`}>
                  {cat.label}
                </span>
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-widest">Nội dung phản ánh</h4>
            <MessageSquare size={14} className="text-blue-500" />
          </div>
          <textarea 
            placeholder="Mô tả chi tiết vấn đề ông/bà gặp phải..." 
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full h-32 p-5 bg-white border border-slate-100 rounded-[24px] text-sm font-medium focus:outline-none focus:ring-2 focus:ring-red-500/20 focus:border-red-500 transition-all shadow-sm resize-none"
            required
          />
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-widest">Vị trí & Hình ảnh</h4>
            <MapPin size={14} className="text-emerald-500" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <button 
              type="button"
              onClick={handleImageUpload}
              className="h-32 bg-white border border-dashed border-slate-200 rounded-[24px] flex flex-col items-center justify-center gap-2 text-slate-400 hover:border-red-500 hover:text-red-500 transition-all group"
            >
              {image ? (
                <img src={image} className="w-full h-full object-cover rounded-[24px]" />
              ) : (
                <>
                  <div className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center group-hover:bg-red-50">
                    <Camera size={20} />
                  </div>
                  <span className="text-[11px] font-bold uppercase">Chụp ảnh</span>
                </>
              )}
            </button>
            <div className="h-32 bg-white border border-slate-100 rounded-[24px] p-4 flex flex-col justify-between shadow-sm">
              <div className="flex items-center gap-2 text-emerald-600">
                <MapPin size={16} />
                <span className="text-[10px] font-black uppercase">Vị trí hiện tại</span>
              </div>
              <input 
                type="text" 
                placeholder="Nhập địa chỉ..." 
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full text-[12px] font-bold text-slate-800 bg-transparent border-none focus:ring-0 p-0 placeholder:text-slate-300"
              />
              <div className="h-1 w-full bg-slate-50 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500 w-2/3"></div>
              </div>
            </div>
          </div>
        </div>

        <div className="p-6 bg-slate-900 rounded-[28px] text-white relative overflow-hidden shadow-xl">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <Clock size={64} />
          </div>
          <div className="relative z-10">
            <h4 className="text-sm font-black mb-1">Thời gian xử lý</h4>
            <p className="text-[11px] text-white/60 leading-relaxed">
              Các phản ánh sẽ được tiếp nhận và xử lý trong vòng 24h - 48h làm việc.
            </p>
          </div>
        </div>

        <button 
          type="submit"
          disabled={!category || !description}
          className="w-full h-16 bg-red-600 text-white rounded-[24px] font-extrabold text-base shadow-xl shadow-red-600/20 flex items-center justify-center gap-3 active:scale-95 transition-all disabled:opacity-50 disabled:scale-100"
        >
          Gửi phản ánh ngay <Send size={20} />
        </button>
      </form>
    </div>
  );
};
