
import React from 'react';
import { 
  ArrowLeft, 
  Phone, 
  ShieldAlert, 
  Flame, 
  PlusCircle, 
  Building, 
  HeartPulse,
  ExternalLink
} from 'lucide-react';

interface HotlineViewProps {
  onBack: () => void;
}

const HOTLINES = [
  {
    category: "Khẩn cấp (24/7)",
    items: [
      { id: 1, name: "Cảnh sát phản ứng nhanh", number: "113", icon: <ShieldAlert className="text-blue-600" />, color: "bg-blue-50" },
      { id: 2, name: "Cảnh sát Phòng cháy chữa cháy", number: "114", icon: <Flame className="text-red-600" />, color: "bg-red-50" },
      { id: 3, name: "Cấp cứu y tế", number: "115", icon: <HeartPulse className="text-emerald-600" />, color: "bg-emerald-50" },
    ]
  },
  {
    category: "Địa phương (Phường Tây Thạnh)",
    items: [
      { id: 4, name: "Công an Phường Tây Thạnh", number: "028 3815 3113", icon: <Building className="text-slate-600" />, color: "bg-slate-50" },
      { id: 5, name: "UBND Phường Tây Thạnh", number: "028 3815 3114", icon: <Building className="text-slate-600" />, color: "bg-slate-50" },
      { id: 6, name: "Trạm Y tế Phường", number: "028 3815 3115", icon: <HeartPulse className="text-slate-600" />, color: "bg-slate-50" },
    ]
  },
  {
    category: "Hỗ trợ khác",
    items: [
      { id: 7, name: "Tổng đài 1022 (Phản ánh kiến nghị)", number: "1022", icon: <Phone className="text-orange-600" />, color: "bg-orange-50" },
      { id: 8, name: "Hỗ trợ điện lực (EVN)", number: "1900 545454", icon: <PlusCircle className="text-yellow-600" />, color: "bg-yellow-50" },
    ]
  }
];

export const HotlineView: React.FC<HotlineViewProps> = ({ onBack }) => {
  const handleCall = (number: string) => {
    window.location.href = `tel:${number.replace(/\s/g, '')}`;
  };

  return (
    <div className="flex flex-col h-full bg-[#F8FAFC] overflow-y-auto animate-in fade-in duration-500 pb-24 no-scrollbar">
      <div className="p-4 flex items-center gap-4 sticky top-0 bg-white/80 backdrop-blur-md z-20 border-b border-slate-100">
        <button onClick={onBack} className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-slate-100 transition-colors">
          <ArrowLeft size={20} className="text-slate-800" />
        </button>
        <h2 className="text-base font-bold text-slate-900">Đường dây nóng hỗ trợ</h2>
      </div>

      <div className="px-5 pt-6 space-y-8">
        <div className="bg-red-600 rounded-[28px] p-6 text-white shadow-xl shadow-red-600/20 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <Phone size={80} />
          </div>
          <div className="relative z-10">
            <h3 className="text-lg font-black mb-1">Cần hỗ trợ khẩn cấp?</h3>
            <p className="text-xs font-medium text-white/80 leading-relaxed mb-4">
              Vui lòng liên hệ ngay các đầu số khẩn cấp bên dưới để được trợ giúp kịp thời 24/7.
            </p>
            <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest bg-white/10 self-start px-3 py-1.5 rounded-full">
              Lưu danh bạ ngay <ExternalLink size={12} />
            </div>
          </div>
        </div>

        {HOTLINES.map((group, idx) => (
          <div key={idx} className="space-y-4">
            <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-widest px-1">{group.category}</h4>
            <div className="grid grid-cols-1 gap-3">
              {group.items.map((item) => (
                <button 
                  key={item.id}
                  onClick={() => handleCall(item.number)}
                  className="bg-white p-4 rounded-[24px] border border-slate-100 shadow-sm flex items-center justify-between hover:border-red-100 transition-all active:scale-[0.98]"
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-2xl ${item.color} flex items-center justify-center`}>
                      {item.icon}
                    </div>
                    <div className="text-left">
                      <h5 className="text-[14px] font-bold text-slate-800 leading-tight">{item.name}</h5>
                      <p className="text-[12px] font-black text-red-600 mt-1">{item.number}</p>
                    </div>
                  </div>
                  <div className="w-10 h-10 rounded-full bg-slate-50 flex items-center justify-center text-slate-400">
                    <Phone size={18} />
                  </div>
                </button>
              ))}
            </div>
          </div>
        ))}

        <div className="p-6 bg-white border border-slate-100 rounded-[28px] text-center space-y-3">
          <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest">Ghi chú</p>
          <p className="text-[12px] text-slate-600 leading-relaxed">
            Các cuộc gọi đến đầu số khẩn cấp 113, 114, 115 là hoàn toàn miễn phí từ mọi thuê bao di động và cố định.
          </p>
        </div>
      </div>
    </div>
  );
};
